extends CharacterBody2D

@export var speed = 200

var movement = Vector2()

var controll = {
	'up': false,
	'down': false,    # Corrigido de 'donw' para 'down'
	'left': false,
	'right': false,
}

func _physics_process(delta):
	controll_loop()
	movenent_loop()
	
func controll_loop():
	self.controll['up'] = Input.is_action_pressed('ui_up')
	self.controll['down'] = Input.is_action_pressed('ui_down')   # Corrigido aqui!
	self.controll['left'] = Input.is_action_pressed('ui_left')
	self.controll['right'] = Input.is_action_pressed('ui_right')
	
func movenent_loop():
	walk()
	velocity = movement * speed
	move_and_slide()

func walk():
	movement = Vector2.ZERO 
	movement.x = -int(self.controll['left']) + int(self.controll['right'])
	movement.y = -int(self.controll['up']) + int(self.controll['down'])   # Corrigido de 'donw' para 'down'
