extends Control

# --- VARIÁVEIS DE ESTADO ---
var estado: String = "menu" # menu, selecao, mapa, jogo
var pais_selecionado: String = ""
var raio_clique: float = 20.0

# --- SISTEMA DE DINHEIRO ---
var dinheiro: float = 13.0577
var ganho_por_segundo: float = 402.774
var tempo_acumulado: float = 0.0

# --- CONFIGURAÇÕES DOS PAÍSES ---
var paises = ["China", "Brasil", "Reino Unido", "Rússia", "Alemanha", "França", "EUA", "Japão"]

var coordenadas_paises = {
	"EUA": Vector2(175, 230),
	"Brasil": Vector2(270, 400),
	"Reino Unido": Vector2(380, 175),
	"França": Vector2(400, 208),
	"Alemanha": Vector2(410, 180),
	"Rússia": Vector2(610, 150),
	"China": Vector2(610, 250),
	"Japão": Vector2(688, 230)
}

# Cores alternativas caso a imagem falhe (pode usar Color(r, g, b))
var cores_teste_cenarios = {
	"China": Color(0.54, 0, 0),
	"Brasil": Color(0.13, 0.54, 0.13),
	"Reino Unido": Color(0, 0, 0.5),
	"Rússia": Color(0.86, 0.86, 0.86),
	"Alemanha": Color(0.85, 0.65, 0.13),
	"França": Color(0.27, 0.51, 0.71),
	"EUA": Color(0.1, 0.1, 0.44),
	"Japão": Color(1, 0.98, 0.98)
}

# Caminhos dos cenários
var arquivos_cenarios = {
	"China": "res://cenario_china.png",
	"Brasil": "res://cenario_brasil.png",
	"Reino Unido": "res://cenario_uk.png",
	"Rússia": "res://cenario_russia.png",
	"Alemanha": "res://cenario_alemanha.png",
	"França": "res://cenario_franca.png",
	"EUA": "res://cenario_eua.png",
	"Japão": "res://cenario_japao.png"
}

# Ícones internos do cenário
var icones_cenarios = [
	{"nome": "Falar com lider", "pos": Vector2(650, 505)},
	{"nome": "ver economia", "pos": Vector2(650, 450)}
]

# --- REFERÊNCIAS DOS NÓS (Certifique-se de que os nomes batem com a sua árvore) ---
@onready var menu_node = $Menu
@onready var selecao_node = $Selecao
@onready var mapa_node = $Mapa
@onready var jogo_node = $Jogo
@onready var marcadores_node = $Mapa/Marcadores
@onready var cenario_img = $Jogo/TextureRectCenario
@onready var label_dinheiro = $HUD/LabelDinheiro
@onready var container_icones = $Jogo/ContainerIcones

func _ready():
	configurar_botoes_selecao()
	mudar_estado("menu")
	# Força a repintura dos marcadores no mapa
	marcadores_node.draw.connect(_desenhar_marcadores)

func _process(delta):
	# --- ATUALIZAÇÃO DO DINHEIRO POR SEGUNDO ---
	tempo_acumulado += delta
	if tempo_acumulado >= 1.0:
		dinheiro += ganho_por_segundo
		tempo_acumulado -= 1.0
	
	# Atualiza o texto do dinheiro formatado
	label_dinheiro.text = "Dinheiro: $ %.4f" % dinheiro

# --- GERENCIADOR DE ESTADOS (Telas) ---
func mudar_estado(novo_estado: String):
	estado = novo_estado
	menu_node.visible = (estado == "menu")
	selecao_node.visible = (estado == "selecao")
	mapa_node.visible = (estado == "mapa")
	jogo_node.visible = (estado == "jogo")
	
	if estado == "mapa":
		marcadores_node.queue_redraw() # Redesenha as bolinhas do mapa

	elif estado == "jogo":
		
		carregar_cenario_pais()

# --- CONFIGURAÇÃO DA TELA DE SELEÇÃO ---
func configurar_botoes_selecao():
	var botoes = $Selecao/GridPaises.get_children()
	for i in range(botoes.size()):
		if i < paises.size():
			botoes[i].text = paises[i]
			botoes[i].pressed.connect(_on_pais_selecionado.bind(paises[i]))

func _on_pais_selecionado(nome_pais: String):
	pais_selecionado = nome_pais
	mudar_estado("mapa")

# --- LÓGICA DO MAPA MÚNDI (Cliques nas Coordenadas) ---
func _input(event):
	if estado == "mapa" and event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		var pos_mouse = event.position
		
		# Verifica se clicou perto de algum país usando math.hypot (distance_to)
		for nome_pais in coordenadas_paises:
			var coord = coordenadas_paises[nome_pais]
			if pos_mouse.distance_to(coord) <= raio_clique:
				pais_selecionado = nome_pais
				marcadores_node.queue_redraw() # Atualiza marcador ativo
				print("País selecionado no mapa: ", pais_selecionado)

# Desenha os círculos idênticos ao Pygame
func _desenhar_marcadores():
	for nome_pais in coordenadas_paises:
		var coord = coordenadas_paises[nome_pais]
		var cor = Color(0.39, 0.39, 0.39) # Inativo (Cinza)
		
		if pais_selecionado == nome_pais:
			cor = Color(1, 0, 0) # Ativo (Vermelho)
			# Borda amarela para o selecionado
			marcadores_node.draw_circle(coord, 12.0, Color(1, 1, 0))
			
		marcadores_node.draw_circle(coord, 10.0, cor)

# --- LÓGICA DO CENÁRIO DO JOGO ---
func carregar_cenario_pais():
	# Limpa ícones anteriores
	for child in container_icones.get_children():
		child.queue_free()
		
	# Tenta carregar imagem, se falhar usa cor sólida de teste
	if ResourceLoader.exists(arquivos_cenarios[pais_selecionado]):
		cenario_img.texture = load(arquivos_cenarios[pais_selecionado])
		cenario_img.modulate = Color(1, 1, 1) # Reseta cor
	else:
		cenario_img.texture = PlaceholderTexture2D.new() # Cria textura vazia
		cenario_img.modulate = cores_teste_cenarios[pais_selecionado] # Aplica a cor do Pygame
	
	# Cria os botões clicáveis dinamicamente dentro do cenário
	for icone in icones_cenarios:
		var btn = Button.new()
		btn.text = icone["nome"]
		btn.position = icone["pos"]
		btn.size = Vector2(120, 50)
		btn.pressed.connect(_on_icone_cenario_clicado.bind(icone["nome"]))
		container_icones.add_child(btn)

func _on_icone_cenario_clicado(nome_icone: String):
	print("Você clicou no ícone: ", nome_icone, " em ", pais_selecionado, "!")
	if nome_icone == "Falar com lider":
		# Coloque a lógica do que acontece aqui
		pass

# --- CONEXÕES DOS BOTÕES FIXOS DA INTERFACE ---
func _on_btn_jogar_pressed():
	mudar_estado("selecao")

func _on_btn_sair_pressed():
	get_tree().quit()

func _on_btn_avancar_mapa_pressed():
	if pais_selecionado != "":
		mudar_estado("jogo")

func _on_btn_voltar_jogo_pressed():
	mudar_estado("mapa")
