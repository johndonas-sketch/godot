extends CharacterBody2D

@export var speed = 200

var movement = Vector2()

# 1. ESTA LINHA PEGA O SEU NÓ DE ANIMAÇÃO AUTOMATICAMENTE:
@onready var anim = $AnimatedSprite2D 

var controll = {
	'up': false,
	'down': false,
	'left': false,
	'right': false,
}

func _physics_process(delta):
	controll_loop()
	movenent_loop()
	
func controll_loop():
	# Lê diretamente o botão físico do teclado (W, S, A, D)
	self.controll['up'] = Input.is_key_pressed(KEY_W)
	self.controll['down'] = Input.is_key_pressed(KEY_S)
	self.controll['left'] = Input.is_key_pressed(KEY_A)
	self.controll['right'] = Input.is_key_pressed(KEY_D)

	
func movenent_loop():
	walk()
	
	velocity = movement * speed
	move_and_slide()
	
	# 2. SISTEMA DE ANIMAÇÃO:
	if movement != Vector2.ZERO:
		anim.play("run") # Mudado de "walk" para "run" para bater com o seu editor!
 # Toca a animação com o nome exato que você criou
		
		# Inverte o lado do desenho dependendo de para onde você anda:
		if movement.x < 0:
			anim.flip_h = true  # Olha para a esquerda
		elif movement.x > 0:
			anim.flip_h = false # Olha para a direita
	else:
		# 3. SE FICAR PARADO, A ANIMAÇÃO PARA NO PRIMEIRO QUADRO:
		anim.stop()
		anim.frame = 0 

func walk():
	movement = Vector2.ZERO 
	movement.x = -int(self.controll['left']) + int(self.controll['right'])
	movement.y = -int(self.controll['up']) + int(self.controll['down'])
