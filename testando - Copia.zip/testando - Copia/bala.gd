extends Area2D

@export var speed = 400

func _physics_process(delta):
	# Faz a bala se mover para a direita constantemente
	position.x += speed * delta
